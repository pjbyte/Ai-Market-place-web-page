// ═══════════════════════════════════════
//  AI TOOLS API ROUTES
// ═══════════════════════════════════════

const express = require('express');
const router = express.Router();
const store = require('../models/store');
const { validateTool } = require('../middleware/validate');

// GET /api/tools — List all tools
router.get('/', (req, res) => {
  const { category, pricing } = req.query;
  let tools = store.getTools();

  if (category) {
    tools = tools.filter(t => t.categories.some(c =>
      c.toLowerCase() === category.toLowerCase()
    ));
  }

  if (pricing) {
    tools = tools.filter(t => t.pricing === pricing);
  }

  res.json({ success: true, count: tools.length, data: tools });
});

// GET /api/tools/search?q= — Search tools
router.get('/search', (req, res) => {
  const { q } = req.query;
  if (!q) {
    return res.status(400).json({ success: false, error: 'Query parameter "q" is required' });
  }
  const results = store.searchTools(q);
  res.json({ success: true, count: results.length, data: results });
});

// GET /api/tools/:id — Get single tool
router.get('/:id', (req, res) => {
  const tool = store.getToolById(parseInt(req.params.id));
  if (!tool) {
    return res.status(404).json({ success: false, error: 'Tool not found' });
  }
  res.json({ success: true, data: tool });
});

// POST /api/tools — Register a new tool
router.post('/', validateTool, (req, res) => {
  const { name, company, categories, desc, url, pricing, email, tags } = req.body;

  const pricingLabels = { free: 'FREE / OSS', freemium: 'FREEMIUM', paid: 'PAID' };

  const newTool = store.addTool({
    name,
    company,
    logo: '🆕',
    logoBg: 'linear-gradient(135deg,#00ffd5,#00c4a7)',
    desc,
    categories: Array.isArray(categories) ? categories : [categories],
    tags: tags || [categories[0] || 'New', 'New'],
    rating: 0,
    pricing,
    pricingLabel: pricingLabels[pricing] || 'FREEMIUM',
    url,
    bestFor: desc.substring(0, 60) + '...',
    hasAPI: false,
    hasApp: false,
    openSource: pricing === 'free',
    contactEmail: email,
  });

  res.status(201).json({ success: true, message: 'Tool listed successfully', data: newTool });
});

// GET /api/categories — List all categories
router.get('/', (req, res) => {
  // This is handled by the first GET / route with query params
});

module.exports = router;
