// ═══════════════════════════════════════
//  AUTH API ROUTES
//  (Basic implementation — add JWT + bcrypt for production)
// ═══════════════════════════════════════

const express = require('express');
const router = express.Router();
const store = require('../models/store');
const { validateUser, validateSignup } = require('../middleware/validate');

// POST /api/auth/signup
router.post('/signup', validateSignup, (req, res) => {
  const { name, email, password } = req.body;

  // Check if user already exists
  const existing = store.findUserByEmail(email);
  if (existing) {
    return res.status(409).json({ success: false, error: 'Email already registered' });
  }

  // In production: hash password with bcrypt
  const user = store.addUser({ name, email, password });

  res.status(201).json({
    success: true,
    message: 'Account created successfully',
    data: { id: user.id, name: user.name, email: user.email }
  });
});

// POST /api/auth/login
router.post('/login', validateUser, (req, res) => {
  const { email, password } = req.body;

  const user = store.findUserByEmail(email);
  if (!user || user.password !== password) {
    return res.status(401).json({ success: false, error: 'Invalid email or password' });
  }

  // In production: return a JWT token
  res.json({
    success: true,
    message: 'Login successful',
    data: { id: user.id, name: user.name, email: user.email }
  });
});

module.exports = router;
