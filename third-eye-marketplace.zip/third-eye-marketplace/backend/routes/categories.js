// ═══════════════════════════════════════
//  CATEGORIES API ROUTE
// ═══════════════════════════════════════

const express = require('express');
const router = express.Router();
const store = require('../models/store');

// GET /api/categories
router.get('/', (req, res) => {
  const categories = store.getCategories();
  res.json({ success: true, count: categories.length, data: categories });
});

module.exports = router;
