// ═══════════════════════════════════════
//  JSON FILE-BASED DATA STORE
//  (Upgrade to MongoDB/PostgreSQL for production)
// ═══════════════════════════════════════

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const TOOLS_FILE = path.join(DATA_DIR, 'tools.json');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// ── Generic helpers ──
function readJSON(filePath, fallback = []) {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    const raw = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function writeJSON(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
}

// ── Tools ──
function getTools() {
  return readJSON(TOOLS_FILE, []);
}

function getToolById(id) {
  const tools = getTools();
  return tools.find(t => t.id === id) || null;
}

function addTool(tool) {
  const tools = getTools();
  tool.id = tools.length > 0 ? Math.max(...tools.map(t => t.id)) + 1 : 1;
  tool.createdAt = new Date().toISOString();
  tools.push(tool);
  writeJSON(TOOLS_FILE, tools);
  return tool;
}

function searchTools(query) {
  const q = query.toLowerCase();
  return getTools().filter(t =>
    t.name.toLowerCase().includes(q) ||
    t.desc.toLowerCase().includes(q) ||
    t.categories.some(c => c.toLowerCase().includes(q)) ||
    t.tags.some(tag => tag.toLowerCase().includes(q)) ||
    t.bestFor.toLowerCase().includes(q)
  );
}

function getCategories() {
  const tools = getTools();
  return [...new Set(tools.flatMap(t => t.categories))].sort();
}

// ── Users ──
function getUsers() {
  return readJSON(USERS_FILE, []);
}

function findUserByEmail(email) {
  return getUsers().find(u => u.email === email) || null;
}

function addUser(user) {
  const users = getUsers();
  user.id = users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1;
  user.createdAt = new Date().toISOString();
  users.push(user);
  writeJSON(USERS_FILE, users);
  return { id: user.id, name: user.name, email: user.email };
}

// ── Initialize default data if empty ──
function initializeDefaults(defaultTools) {
  if (getTools().length === 0 && defaultTools && defaultTools.length > 0) {
    writeJSON(TOOLS_FILE, defaultTools.map((t, i) => ({
      ...t,
      id: i + 1,
      createdAt: new Date().toISOString()
    })));
    console.log(`  ✔ Initialized ${defaultTools.length} default tools`);
  }
}

module.exports = {
  getTools,
  getToolById,
  addTool,
  searchTools,
  getCategories,
  getUsers,
  findUserByEmail,
  addUser,
  initializeDefaults,
};
