// ═══════════════════════════════════════
//  THIRD EYE — EXPRESS SERVER
// ═══════════════════════════════════════

require('dotenv').config();

const express = require('express');
const cors = require('cors');
const path = require('path');
const config = require('./config/defaults');
const store = require('./models/store');

const app = express();

// ── Middleware ──
app.use(cors({ origin: config.corsOrigins }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Request Logger (dev only) ──
if (config.env === 'development') {
  app.use((req, res, next) => {
    const timestamp = new Date().toISOString().slice(11, 19);
    console.log(`  [${timestamp}] ${req.method} ${req.url}`);
    next();
  });
}

// ── Static Files (Frontend) ──
app.use(express.static(path.join(__dirname, '..', 'public')));

// ── API Routes ──
const toolsRouter = require('./routes/tools');
const authRouter = require('./routes/auth');
const categoriesRouter = require('./routes/categories');

app.use('/api/tools', toolsRouter);
app.use('/api/auth', authRouter);
app.use('/api/categories', categoriesRouter);

// ── Health Check ──
app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    message: 'Third Eye API is running',
    version: '1.0.0',
    environment: config.env,
    timestamp: new Date().toISOString(),
  });
});

// ── Catch-all: serve frontend for any non-API route (SPA support) ──
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// ── Global Error Handler ──
app.use((err, req, res, next) => {
  console.error('  ✘ Server Error:', err.message);
  res.status(500).json({
    success: false,
    error: config.env === 'development' ? err.message : 'Internal server error',
  });
});

// ── Start Server ──
app.listen(config.port, () => {
  console.log('');
  console.log('  ╔══════════════════════════════════════╗');
  console.log('  ║     👁️  THIRD EYE — AI MARKETPLACE    ║');
  console.log('  ╚══════════════════════════════════════╝');
  console.log('');
  console.log(`  ➜  Server:   http://localhost:${config.port}`);
  console.log(`  ➜  API:      http://localhost:${config.port}/api/tools`);
  console.log(`  ➜  Health:   http://localhost:${config.port}/api/health`);
  console.log(`  ➜  Mode:     ${config.env}`);
  console.log('');

  // Initialize default tool data if store is empty
  const defaultTools = require('./data/tools.json');
  store.initializeDefaults(defaultTools);
});

module.exports = app;
