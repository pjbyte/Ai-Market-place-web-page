// ═══════════════════════════════════════
//  REQUEST VALIDATION MIDDLEWARE
// ═══════════════════════════════════════

function validateTool(req, res, next) {
  const { name, company, categories, desc, url, pricing, email } = req.body;

  const errors = [];
  if (!name || !name.trim()) errors.push('Product name is required');
  if (!company || !company.trim()) errors.push('Company name is required');
  if (!categories || !Array.isArray(categories) || categories.length === 0) errors.push('At least one category is required');
  if (!desc || !desc.trim()) errors.push('Description is required');
  if (!url || !url.trim()) errors.push('Website URL is required');
  if (!pricing || !['free', 'freemium', 'paid'].includes(pricing)) errors.push('Valid pricing model is required (free, freemium, paid)');
  if (!email || !email.includes('@')) errors.push('Valid contact email is required');

  if (errors.length > 0) {
    return res.status(400).json({ success: false, errors });
  }

  next();
}

function validateUser(req, res, next) {
  const { email, password } = req.body;

  const errors = [];
  if (!email || !email.includes('@')) errors.push('Valid email is required');
  if (!password || password.length < 6) errors.push('Password must be at least 6 characters');

  if (errors.length > 0) {
    return res.status(400).json({ success: false, errors });
  }

  next();
}

function validateSignup(req, res, next) {
  const { name } = req.body;

  if (!name || !name.trim()) {
    return res.status(400).json({ success: false, errors: ['Full name is required'] });
  }

  // Chain to user validation
  validateUser(req, res, next);
}

module.exports = { validateTool, validateUser, validateSignup };
