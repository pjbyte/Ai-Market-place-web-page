// ═══════════════════════════════════════
//  THIRD EYE — ADVISOR CHATBOT
// ═══════════════════════════════════════

function toggleAdvisor() {
  document.getElementById('advisorPanel').classList.toggle('open');
}

function askAdvisor(text) {
  document.getElementById('advisorInput').value = text;
  sendAdvisor();
}

function sendAdvisor() {
  const input = document.getElementById('advisorInput');
  const text = input.value.trim();
  if (!text) return;
  input.value = '';

  const body = document.getElementById('advisorBody');
  body.innerHTML += `<div class="msg user">${escapeHtml(text)}</div>`;
  document.getElementById('suggestChips').style.display = 'none';

  setTimeout(() => {
    body.innerHTML += `<div class="msg bot">${getReply(text)}</div>`;
    body.scrollTop = body.scrollHeight;
  }, 700);
  body.scrollTop = body.scrollHeight;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ── Rule-Based Reply Engine ──
function getReply(q) {
  const ql = q.toLowerCase();

  const rules = [
    {
      keywords: ['writ', 'blog', 'essay', 'content', 'article', 'copy'],
      reply: `👁️ <b>Third Eye sees your path for writing:</b><br><br>
        🥇 <b>Claude</b> — Best for long-form, nuanced writing (200K context). Excellent tone & structure.<br>
        🥈 <b>ChatGPT</b> — Great all-rounder for blogs, emails & creative writing.<br>
        🥉 <b>Notion AI</b> — Perfect inside the Notion workflow.<br><br>
        ✨ My pick: <b>Claude</b> for reports, <b>ChatGPT</b> for versatile daily writing.`
    },
    {
      keywords: ['code', 'coding', 'program', 'develop', 'debug', 'javascript', 'python', 'dev'],
      reply: `👁️ <b>Third Eye sees your path for coding:</b><br><br>
        🥇 <b>GitHub Copilot</b> — Real-time autocomplete in VS Code. Best for daily coding.<br>
        🥈 <b>Claude</b> — Complex code reasoning, debugging & large codebase analysis.<br>
        🥉 <b>ChatGPT</b> — Quick scripts, learning & explanations.<br><br>
        ✨ Power combo: <b>Copilot</b> in your IDE + <b>Claude</b> for hard problems.`
    },
    {
      keywords: ['image', 'art', 'design', 'draw', 'picture', 'illustrat', 'logo', 'visual'],
      reply: `👁️ <b>Third Eye sees your path for images:</b><br><br>
        🥇 <b>Midjourney</b> — Stunning artistic quality. Best for concept art & photorealism.<br>
        🥈 <b>DALL·E 3</b> — Easiest (built into ChatGPT). Great text rendering.<br>
        🥉 <b>Stable Diffusion</b> — Free, open-source, fully customizable locally.<br><br>
        ✨ Quality → Midjourney | Easy → DALL·E | Control → Stable Diffusion`
    },
    {
      keywords: ['video', 'film', 'animation', 'edit video'],
      reply: `👁️ <b>Third Eye sees your path for video:</b><br><br>
        🥇 <b>Runway ML</b> — Leader in AI video. Text-to-video, inpainting, VFX & Gen-3 Alpha.<br><br>
        ✨ <b>Runway ML</b> is the clear winner for AI video production.`
    },
    {
      keywords: ['voice', 'audio', 'speech', 'tts', 'podcast', 'narrat', 'dub'],
      reply: `👁️ <b>Third Eye sees your path for voice/audio:</b><br><br>
        🥇 <b>ElevenLabs</b> — Industry-leading voice synthesis. 29 languages, voice cloning, emotional range.<br><br>
        ✨ <b>ElevenLabs</b> is the undisputed champion for voice AI.`
    },
    {
      keywords: ['research', 'search', 'fact', 'source', 'citation', 'academic'],
      reply: `👁️ <b>Third Eye sees your path for research:</b><br><br>
        🥇 <b>Perplexity AI</b> — Built for research. Cited, sourced answers with real-time web search.<br>
        🥈 <b>Claude</b> — Analyze long research papers (200K context).<br>
        🥉 <b>Gemini</b> — Strong Google Search integration for real-time info.<br><br>
        ✨ <b>Perplexity</b> for sourced answers, <b>Claude</b> for deep analysis.`
    },
    {
      keywords: ['free', 'no cost', 'open source', 'budget', 'cheap', 'oss'],
      reply: `👁️ <b>Third Eye sees free paths:</b><br><br>
        🆓 <b>ChatGPT</b> — Solid free tier for general use.<br>
        🆓 <b>Claude</b> — Great free tier for writing & analysis.<br>
        🆓 <b>Gemini</b> — Free with Google integration.<br>
        🆓 <b>Perplexity</b> — Excellent free research tool.<br>
        🔓 <b>Stable Diffusion</b> — Fully free & open source.<br>
        🔓 <b>Hugging Face</b> — 500K+ free models & datasets.<br><br>
        ✨ You can accomplish a LOT without spending a rupee!`
    },
    {
      keywords: ['best', 'recommend', 'which', 'compare', 'vs', 'should'],
      reply: `👁️ <b>Third Eye's quick guide by task:</b><br><br>
        📝 Writing → <b>Claude</b> or <b>ChatGPT</b><br>
        💻 Coding → <b>GitHub Copilot</b> + <b>Claude</b><br>
        🎨 Images → <b>Midjourney</b> or <b>DALL·E 3</b><br>
        🔍 Research → <b>Perplexity AI</b><br>
        🎬 Video → <b>Runway ML</b><br>
        🎙️ Voice → <b>ElevenLabs</b><br>
        🤗 Open Source → <b>Hugging Face</b><br><br>
        Tell me your exact task for a tailored recommendation!`
    },
  ];

  for (const rule of rules) {
    if (rule.keywords.some(k => ql.includes(k))) return rule.reply;
  }

  return `👁️ Interesting question! Based on what I can see, I'd suggest:<br><br>
    • For <b>general tasks</b> → ChatGPT or Claude<br>
    • For <b>specialized tasks</b> → Use the category filters above<br><br>
    Try asking me about "writing", "coding", "images", "video", "voice", "research", or "free AI" for detailed picks! 🎯`;
}
