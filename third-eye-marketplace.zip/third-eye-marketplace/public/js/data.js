// ═══════════════════════════════════════
//  AI TOOLS DATABASE
// ═══════════════════════════════════════
const aiTools = [
  {
    id: 1,
    name: "ChatGPT", company: "OpenAI", logo: "🟢",
    logoBg: "linear-gradient(135deg,#10a37f,#0d8c6d)",
    desc: "Versatile conversational AI excelling at writing, brainstorming, analysis, math, and general Q&A. Powered by GPT-4o and GPT-4 Turbo.",
    categories: ["Chatbot","Writing","Coding","Research"],
    tags: ["NLP","GPT-4","Plugins","DALL·E"],
    rating: 4.7, pricing: "freemium", pricingLabel: "FREEMIUM",
    url: "https://chat.openai.com",
    bestFor: "General conversations, writing, brainstorming & learning",
    hasAPI: true, hasApp: true, openSource: false
  },
  {
    id: 2,
    name: "Claude", company: "Anthropic", logo: "🟠",
    logoBg: "linear-gradient(135deg,#d97706,#b45309)",
    desc: "Known for nuanced reasoning, long document analysis, and safety. Handles 200K tokens of context for deep research and coding.",
    categories: ["Chatbot","Writing","Coding","Research"],
    tags: ["200K CTX","Safe AI","Analysis","Coding"],
    rating: 4.8, pricing: "freemium", pricingLabel: "FREEMIUM",
    url: "https://claude.ai",
    bestFor: "Long doc analysis, safe reasoning, coding & research",
    hasAPI: true, hasApp: true, openSource: false
  },
  {
    id: 3,
    name: "Gemini", company: "Google", logo: "🔵",
    logoBg: "linear-gradient(135deg,#4285f4,#1a73e8)",
    desc: "Google's multimodal AI integrated with Search, Gmail, Docs. Strong at research, summarization, and real-time information.",
    categories: ["Chatbot","Research","Writing","Multimodal"],
    tags: ["Google","Multimodal","Search","Workspace"],
    rating: 4.5, pricing: "freemium", pricingLabel: "FREEMIUM",
    url: "https://gemini.google.com",
    bestFor: "Research with web access & Google Workspace integration",
    hasAPI: true, hasApp: true, openSource: false
  },
  {
    id: 4,
    name: "Midjourney", company: "Midjourney Inc.", logo: "🎨",
    logoBg: "linear-gradient(135deg,#7c3aed,#5b21b6)",
    desc: "Leading AI image generator producing stunning artistic visuals. Renowned for photorealistic and fantasy art styles.",
    categories: ["Image Generation","Design","Creative"],
    tags: ["Art","Photorealistic","Discord","Creative"],
    rating: 4.8, pricing: "paid", pricingLabel: "FROM $10/MO",
    url: "https://www.midjourney.com",
    bestFor: "High-quality artistic image generation & concept art",
    hasAPI: false, hasApp: false, openSource: false
  },
  {
    id: 5,
    name: "GitHub Copilot", company: "GitHub / Microsoft", logo: "🐙",
    logoBg: "linear-gradient(135deg,#238636,#1a7f37)",
    desc: "AI pair programmer that autocompletes code, explains functions, writes tests, and generates entire blocks inside your IDE.",
    categories: ["Coding","Developer Tools"],
    tags: ["VS Code","Autocomplete","Pair Prog","Multi-lang"],
    rating: 4.6, pricing: "paid", pricingLabel: "FROM $10/MO",
    url: "https://github.com/features/copilot",
    bestFor: "Real-time code completion & pair programming in IDE",
    hasAPI: true, hasApp: true, openSource: false
  },
  {
    id: 6,
    name: "DALL·E 3", company: "OpenAI", logo: "🖼️",
    logoBg: "linear-gradient(135deg,#f59e0b,#d97706)",
    desc: "Text-to-image AI integrated into ChatGPT. Generates detailed images from prompts with strong adherence and text rendering.",
    categories: ["Image Generation","Design","Creative"],
    tags: ["Text-to-Image","ChatGPT","Creative","Design"],
    rating: 4.5, pricing: "freemium", pricingLabel: "FREEMIUM",
    url: "https://openai.com/dall-e-3",
    bestFor: "Quick image generation with natural language prompts",
    hasAPI: true, hasApp: false, openSource: false
  },
  {
    id: 7,
    name: "Stable Diffusion", company: "Stability AI", logo: "🌀",
    logoBg: "linear-gradient(135deg,#ec4899,#be185d)",
    desc: "Open-source image generation you can run locally. Highly customizable with LoRA fine-tuning and community models.",
    categories: ["Image Generation","Design","Open Source"],
    tags: ["Open Source","Local","Custom","LoRA"],
    rating: 4.4, pricing: "free", pricingLabel: "FREE / OSS",
    url: "https://stability.ai",
    bestFor: "Customizable local image generation with full control",
    hasAPI: true, hasApp: false, openSource: true
  },
  {
    id: 8,
    name: "Perplexity AI", company: "Perplexity", logo: "🔍",
    logoBg: "linear-gradient(135deg,#06b6d4,#0891b2)",
    desc: "AI-powered search engine providing cited, sourced answers. Combines LLMs with real-time web search for research.",
    categories: ["Research","Search","Chatbot"],
    tags: ["Citations","Web Search","Real-time","Research"],
    rating: 4.6, pricing: "freemium", pricingLabel: "FREEMIUM",
    url: "https://www.perplexity.ai",
    bestFor: "Research with cited sources & real-time web info",
    hasAPI: true, hasApp: true, openSource: false
  },
  {
    id: 9,
    name: "ElevenLabs", company: "ElevenLabs", logo: "🎙️",
    logoBg: "linear-gradient(135deg,#6366f1,#4f46e5)",
    desc: "State-of-the-art AI voice generation and cloning. Natural speech in 29 languages with emotional range and custom voices.",
    categories: ["Audio","Voice","Creative"],
    tags: ["TTS","Voice Clone","Multilingual","Dubbing"],
    rating: 4.7, pricing: "freemium", pricingLabel: "FREEMIUM",
    url: "https://elevenlabs.io",
    bestFor: "Realistic AI voice generation, cloning & dubbing",
    hasAPI: true, hasApp: true, openSource: false
  },
  {
    id: 10,
    name: "Runway ML", company: "Runway", logo: "🎬",
    logoBg: "linear-gradient(135deg,#ef4444,#dc2626)",
    desc: "AI-powered video generation and editing suite. Create videos from text/images, remove backgrounds, and apply VFX.",
    categories: ["Video","Creative","Design"],
    tags: ["Text-to-Video","Video Edit","Gen-3","VFX"],
    rating: 4.5, pricing: "freemium", pricingLabel: "FREEMIUM",
    url: "https://runwayml.com",
    bestFor: "AI video generation & professional editing workflows",
    hasAPI: true, hasApp: false, openSource: false
  },
  {
    id: 11,
    name: "Hugging Face", company: "Hugging Face", logo: "🤗",
    logoBg: "linear-gradient(135deg,#fbbf24,#f59e0b)",
    desc: "Largest open-source AI platform hosting 500K+ models, datasets, and Spaces. Hub for NLP, vision, audio, and ML.",
    categories: ["Developer Tools","Open Source","Research"],
    tags: ["Models Hub","Datasets","Transformers","Community"],
    rating: 4.7, pricing: "free", pricingLabel: "FREE / OSS",
    url: "https://huggingface.co",
    bestFor: "Open-source models, datasets & ML experimentation",
    hasAPI: true, hasApp: false, openSource: true
  },
  {
    id: 12,
    name: "Notion AI", company: "Notion", logo: "📝",
    logoBg: "linear-gradient(135deg,#a3a3a3,#737373)",
    desc: "AI writing and knowledge assistant built into Notion. Summarizes, generates content, extracts action items from your workspace.",
    categories: ["Writing","Productivity"],
    tags: ["Workspace","Summarize","Drafting","Knowledge"],
    rating: 4.3, pricing: "paid", pricingLabel: "ADD-ON $10/MO",
    url: "https://www.notion.so/product/ai",
    bestFor: "Writing assistance & knowledge management in Notion",
    hasAPI: false, hasApp: true, openSource: false
  },
];

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = aiTools;
}
