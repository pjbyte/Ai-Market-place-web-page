// ═══════════════════════════════════════
//  THIRD EYE — MAIN APPLICATION
// ═══════════════════════════════════════

// ── State ──
let activeCategory = "All";
let currentUser = null;

// ── Category System ──
const allCategories = [...new Set(aiTools.flatMap(t => t.categories))].sort();

function renderPills() {
  const wrap = document.getElementById('categoryPills');
  let html = `<span class="cat-pill ${activeCategory === 'All' ? 'active' : ''}" onclick="setCategory('All')">ALL</span>`;
  allCategories.forEach(c => {
    html += `<span class="cat-pill ${activeCategory === c ? 'active' : ''}" onclick="setCategory('${c}')">${c.toUpperCase()}</span>`;
  });
  wrap.innerHTML = html;
}

function setCategory(c) {
  activeCategory = c;
  renderPills();
  filterCards();
}

// ── Star Renderer ──
function renderStars(rating) {
  const full = Math.floor(rating);
  const half = rating % 1 >= 0.5;
  let html = '';
  for (let i = 0; i < 5; i++) {
    html += i < full ? '<span class="star-filled">★</span>' :
            (i === full && half ? '<span class="star-filled">★</span>' :
            '<span class="star-empty">★</span>');
  }
  return html;
}

// ── Filter & Render Cards ──
function filterCards() {
  const q = document.getElementById('searchInput').value.toLowerCase();
  const filtered = aiTools.filter(t => {
    const matchCat = activeCategory === 'All' || t.categories.includes(activeCategory);
    const matchSearch = !q ||
      t.name.toLowerCase().includes(q) ||
      t.desc.toLowerCase().includes(q) ||
      t.tags.some(tag => tag.toLowerCase().includes(q)) ||
      t.categories.some(cat => cat.toLowerCase().includes(q)) ||
      t.bestFor.toLowerCase().includes(q);
    return matchCat && matchSearch;
  });

  document.getElementById('resultCount').textContent = `${filtered.length} TOOL${filtered.length !== 1 ? 'S' : ''}`;

  const grid = document.getElementById('aiGrid');
  grid.innerHTML = filtered.map(t => `
    <div class="card">
      <div class="card-inner">
        <div class="card-header">
          <div class="card-logo" style="background:${t.logoBg}">${t.logo}</div>
          <div>
            <div class="card-title">${t.name.toUpperCase()}</div>
            <div class="card-company">${t.company}</div>
          </div>
        </div>
        <div class="card-best-for">
          <span>BEST FOR</span>
          ${t.bestFor}
        </div>
        <div class="card-desc">${t.desc}</div>
        <div class="card-tags">
          ${t.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
        </div>
        <div class="card-footer">
          <div class="rating">
            <div class="rating-stars">${renderStars(t.rating)}</div>
            <span class="rating-val">${t.rating}</span>
          </div>
          <span class="pricing-badge ${t.pricing}">${t.pricingLabel}</span>
        </div>
        <a href="${t.url}" target="_blank" rel="noopener" class="visit-btn"><span>VISIT ${t.name.toUpperCase()} →</span></a>
      </div>
    </div>
  `).join('');
}

// ── Compare Table ──
function renderCompare() {
  const features = ['Company', 'Best For', 'Rating', 'Pricing', 'Has API', 'Mobile App', 'Open Source'];
  let html = '<thead><tr><th>FEATURE</th>';
  aiTools.forEach(t => html += `<th>${t.name.toUpperCase()}</th>`);
  html += '</tr></thead><tbody>';

  features.forEach(f => {
    html += '<tr><td>' + f.toUpperCase() + '</td>';
    aiTools.forEach(t => {
      let v = '';
      switch (f) {
        case 'Company':    v = t.company; break;
        case 'Best For':   v = t.bestFor; break;
        case 'Rating':     v = `<span style="color:var(--gold)">★</span> ${t.rating}`; break;
        case 'Pricing':    v = t.pricingLabel; break;
        case 'Has API':    v = t.hasAPI ? '<span class="ico-check">✔</span>' : '<span class="ico-cross">✘</span>'; break;
        case 'Mobile App': v = t.hasApp ? '<span class="ico-check">✔</span>' : '<span class="ico-cross">✘</span>'; break;
        case 'Open Source': v = t.openSource ? '<span class="ico-check">✔</span>' : '<span class="ico-cross">✘</span>'; break;
      }
      html += `<td>${v}</td>`;
    });
    html += '</tr>';
  });

  html += '</tbody>';
  document.getElementById('compareTable').innerHTML = html;
}

// ── Section Toggle ──
function showSection(s) {
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  if (s === 'marketplace') {
    document.getElementById('marketplace-section').style.display = 'block';
    document.getElementById('compare-section').style.display = 'none';
    document.getElementById('heroSection').style.display = 'block';
    document.querySelectorAll('.nav-btn')[0].classList.add('active');
  } else {
    document.getElementById('marketplace-section').style.display = 'none';
    document.getElementById('compare-section').style.display = 'block';
    document.getElementById('heroSection').style.display = 'none';
    document.querySelectorAll('.nav-btn')[1].classList.add('active');
    renderCompare();
  }
}

// ── Modal System ──
function openModal(id) {
  document.getElementById(id).classList.add('open');
}

function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

function switchModal(from, to) {
  closeModal(from);
  setTimeout(() => openModal(to), 200);
}

// Close on overlay click
document.querySelectorAll('.modal-overlay').forEach(el => {
  el.addEventListener('click', e => {
    if (e.target === el) el.classList.remove('open');
  });
});

// ── Toast Notification ──
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = '✔ ' + msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3000);
}

// ── Auth Handlers ──
function handleLogin() {
  const email = document.getElementById('loginEmail').value;
  const pass = document.getElementById('loginPass').value;
  if (!email || !pass) { alert('Please fill all fields'); return; }

  currentUser = { email, name: email.split('@')[0] };
  closeModal('loginModal');
  document.getElementById('loginBtn').textContent = currentUser.name.toUpperCase();
  document.getElementById('loginBtn').onclick = () => {
    currentUser = null;
    document.getElementById('loginBtn').textContent = 'LOGIN';
    document.getElementById('loginBtn').onclick = () => openModal('loginModal');
    showToast('LOGGED OUT');
  };
  showToast('LOGGED IN AS ' + currentUser.name.toUpperCase());
}

function handleSignup() {
  const name = document.getElementById('signupName').value;
  const email = document.getElementById('signupEmail').value;
  const pass = document.getElementById('signupPass').value;
  if (!name || !email || !pass) { alert('Please fill all fields'); return; }

  currentUser = { email, name };
  closeModal('signupModal');
  document.getElementById('loginBtn').textContent = name.toUpperCase();
  showToast('ACCOUNT CREATED!');
}

function handleRegister() {
  const c = document.getElementById('regCompany').value;
  const p = document.getElementById('regProduct').value;
  const cat = document.getElementById('regCategory').value;
  const url = document.getElementById('regURL').value;
  const desc = document.getElementById('regDesc').value;
  const pricing = document.getElementById('regPricing').value;
  const email = document.getElementById('regEmail').value;

  if (!c || !p || !cat || !url || !desc || !email) {
    alert('Please fill all required fields');
    return;
  }

  // Add to marketplace
  const pricingLabels = { free: 'FREE / OSS', freemium: 'FREEMIUM', paid: 'PAID' };
  aiTools.push({
    id: aiTools.length + 1,
    name: p, company: c, logo: '🆕',
    logoBg: 'linear-gradient(135deg,#00ffd5,#00c4a7)',
    desc, categories: [cat], tags: [cat, 'New'],
    rating: 0, pricing, pricingLabel: pricingLabels[pricing],
    url, bestFor: desc.substring(0, 60) + '...',
    hasAPI: false, hasApp: false, openSource: pricing === 'free'
  });

  closeModal('registerModal');
  filterCards();
  document.querySelector('.hero-badge').innerHTML =
    `<div class="pulse-dot"></div>${aiTools.length} AI TOOLS LISTED`;
  showToast('AI LISTING SUBMITTED — ' + p.toUpperCase());

  // Clear form
  ['regCompany', 'regProduct', 'regURL', 'regDesc', 'regEmail'].forEach(id =>
    document.getElementById(id).value = '');
  document.getElementById('regCategory').selectedIndex = 0;
}

// ── Keyboard Shortcuts ──
document.addEventListener('keydown', e => {
  if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
    e.preventDefault();
    document.getElementById('searchInput').focus();
  }
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('open'));
  }
});

// ── Initialize ──
document.addEventListener('DOMContentLoaded', () => {
  renderPills();
  filterCards();
});
