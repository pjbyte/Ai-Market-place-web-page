# 👁️ Third Eye — AI Marketplace

![License](https://img.shields.io/badge/license-MIT-green)
![Node](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen)
![Status](https://img.shields.io/badge/status-active-blue)

> The all-seeing marketplace for AI tools. Discover, compare, and find the perfect AI for every task.

## ✨ Features

- **AI Tool Directory** — Browse 12+ curated AI tools with ratings, pricing, and descriptions
- **Smart Search** — Filter by category, keyword, or use case
- **Side-by-Side Compare** — Feature comparison table across all listed tools
- **AI Advisor Bot** — Rule-based chatbot recommending the best AI for your needs
- **Company Registration** — Submit your AI product to be listed on the marketplace
- **User Auth** — Login / Signup system with session management
- **Responsive Design** — Glassmorphism UI with animated backgrounds, works on all devices

## 🛠️ Tech Stack

| Layer       | Technology                          |
|-------------|-------------------------------------|
| Frontend    | HTML5, CSS3, Vanilla JavaScript     |
| Backend     | Node.js, Express.js                 |
| Database    | JSON file-based (upgradeable to MongoDB) |
| Styling     | Custom CSS with CSS Variables, Glassmorphism |
| Fonts       | Press Start 2P, Silkscreen, DM Sans |

## 📁 Project Structure

```
third-eye-marketplace/
├── public/                  # Frontend static files
│   ├── index.html           # Main HTML page
│   ├── css/
│   │   └── styles.css       # All styles
│   ├── js/
│   │   ├── data.js          # AI tools database
│   │   ├── app.js           # Core app logic (render, filter, modals)
│   │   └── advisor.js       # Advisor chatbot logic
│   └── assets/
│       └── logo.svg         # Third Eye logo
├── backend/
│   ├── server.js            # Express server entry point
│   ├── config/
│   │   └── defaults.js      # Server configuration
│   ├── routes/
│   │   ├── tools.js         # API routes for AI tools
│   │   ├── auth.js          # Auth routes (login/signup)
│   │   └── register.js      # Company registration routes
│   ├── middleware/
│   │   └── validate.js      # Request validation middleware
│   ├── models/
│   │   └── store.js         # JSON file-based data store
│   └── data/
│       └── tools.json       # Persistent tools data
├── .gitignore
├── .env.example
├── package.json
├── LICENSE
└── README.md
```

## 🚀 Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) v18 or higher
- npm (comes with Node.js)

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/third-eye-marketplace.git
cd third-eye-marketplace

# 2. Install dependencies
npm install

# 3. Create environment file
cp .env.example .env

# 4. Start the development server
npm run dev

# 5. Open in browser
# Visit http://localhost:3000
```

### Available Scripts

| Command         | Description                    |
|-----------------|--------------------------------|
| `npm start`     | Start production server        |
| `npm run dev`   | Start with auto-reload (nodemon) |

## 📡 API Endpoints

| Method | Endpoint              | Description                  |
|--------|-----------------------|------------------------------|
| GET    | `/api/tools`          | Get all AI tools             |
| GET    | `/api/tools/:id`      | Get a single tool by ID      |
| POST   | `/api/tools`          | Register a new AI tool       |
| GET    | `/api/tools/search?q=`| Search tools by keyword      |
| GET    | `/api/categories`     | Get all categories           |
| POST   | `/api/auth/login`     | User login                   |
| POST   | `/api/auth/signup`    | User registration            |

## 🎨 Screenshots

The marketplace features a dark cyberpunk-inspired glassmorphism UI with animated gradient backgrounds, floating orbs, and a grid overlay.

## 🔮 Roadmap

- [ ] MongoDB / PostgreSQL integration
- [ ] JWT-based authentication with password hashing
- [ ] User reviews and ratings system
- [ ] Admin dashboard for managing listings
- [ ] AI-powered advisor using LLM API
- [ ] Bookmark / favorites system
- [ ] Email notifications for new listings

## 📜 License

This project is licensed under the MIT License — see the [LICENSE](LICENSE) file.

## 👤 Author

**Final Year Project — AI Marketplace © 2026**

---

<p align="center">
  <b>👁️ THIRD EYE</b> — The all-seeing AI marketplace
</p>
